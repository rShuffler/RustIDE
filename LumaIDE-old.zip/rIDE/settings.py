import customtkinter as ctk
import json
import os

class SettingsWindow(ctk.CTkToplevel):
    def __init__(self, master=None, ide_master=None):
        super().__init__(master)
        self.master = master
        self.ide_master = ide_master  # Сохраняем ссылку на главное окно IDE
        self.title("Настройки")
        self.geometry("400x400")
        self.resizable(False, False)

        ctk.CTkLabel(self, text="Настройки LumaIDE", font=("Arial", 18)).pack(pady=10)

        # Настройки темы
        ctk.CTkLabel(self, text="Тема:").pack(anchor="w", padx=20, pady=(10, 0))
        self.theme_option = ctk.CTkOptionMenu(self, values=["Dark", "Light"], command=self.change_theme)
        self.theme_option.set("Dark")
        self.theme_option.pack(padx=20, pady=5)

        # Настройки шрифта
        ctk.CTkLabel(self, text="Шрифт:").pack(anchor="w", padx=20, pady=(10, 0))
        self.font_family = ctk.CTkOptionMenu(self, values=["Arial", "Courier", "Helvetica"], command=self.change_font)
        self.font_family.set("Arial")
        self.font_family.pack(padx=20, pady=5)

        # Настройки размера шрифта
        ctk.CTkLabel(self, text="Размер шрифта:").pack(anchor="w", padx=20, pady=(10, 0))
        self.font_size = ctk.CTkOptionMenu(self, values=["12", "14", "16", "18"], command=self.change_font_size)
        self.font_size.set("14")
        self.font_size.pack(padx=20, pady=5)

        # Автосохранение
        self.autosave_var = ctk.BooleanVar(value=True)
        self.autosave_checkbox = ctk.CTkCheckBox(self, text="Автосохранение", variable=self.autosave_var)
        self.autosave_checkbox.pack(pady=5)

        # Кнопки сохранения и закрытия
        self.save_button = ctk.CTkButton(self, text="Сохранить", command=self.save_settings)
        self.save_button.pack(pady=10)

        self.load_settings()

    def change_theme(self, choice):
        ctk.set_appearance_mode(choice)

    def change_font(self, font):
        self.ide_master.font_family = font  # Обновляем шрифт в главном окне
        self.ide_master.refresh_editor_font()  # Обновляем шрифт в редакторе

    def change_font_size(self, size):
        self.ide_master.font_size = int(size)  # Обновляем размер шрифта в главном окне
        self.ide_master.refresh_editor_font_size()  # Обновляем размер шрифта в редакторе

    def save_settings(self):
        settings = {
            "theme": ctk.get_appearance_mode(),
            "font": self.font_family.get(),
            "font_size": self.font_size.get(),
            "autosave": self.autosave_var.get()
        }
        with open("settings.json", "w") as f:
            json.dump(settings, f)

    def load_settings(self):
        if os.path.exists("settings.json"):
            with open("settings.json", "r") as f:
                settings = json.load(f)
                ctk.set_appearance_mode(settings["theme"])
                self.font_family.set(settings["font"])
                self.font_size.set(settings["font_size"])
                self.autosave_var.set(settings["autosave"])

import customtkinter as ctk
from tkinter import filedialog, messagebox, ttk
import os
import subprocess
from settings import SettingsWindow


ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class MyIDE(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("LumaIDE")
        self.geometry("1200x700")
        self.project_path = None
        self.open_files = {}

        # Главный фрейм
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.pack(fill="both", expand=True)

        # Меню
        self.menu_bar = ctk.CTkFrame(self.main_frame, height=40)
        self.menu_bar.pack(fill="x", side="top")
        ctk.CTkButton(self.menu_bar, text="Открыть папку", command=self.open_folder).pack(side="left", padx=5, pady=5)
        ctk.CTkButton(self.menu_bar, text="Сохранить", command=self.save_current_file).pack(side="left", padx=5)
        ctk.CTkButton(self.menu_bar, text="Выполнить", command=self.run_current_file).pack(side="left", padx=5)
        ctk.CTkButton(self.menu_bar, text="⚙ Настройки", command=self.open_settings).pack(side="right", padx=5)

        # Разделение: слева дерево, справа редактор
        self.content = ctk.CTkFrame(self.main_frame)
        self.content.pack(fill="both", expand=True)

        self.file_tree = ctk.CTkFrame(self.content, width=250)
        self.file_tree.pack(side="left", fill="y", padx=5, pady=5)

        self.editor_area = ctk.CTkFrame(self.content)
        self.editor_area.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        self.editor_tabs = {}

        # Создание вкладок для консоли, проблем и терминала с использованием ttk.Notebook
        self.output_notebook = ttk.Notebook(self)
        self.output_notebook.pack(fill="x", padx=5, pady=5)

        # Создаем вкладки
        self.console_tab = ctk.CTkFrame(self.output_notebook)
        self.output_notebook.add(self.console_tab, text="Console")
        self.problems_tab = ctk.CTkFrame(self.output_notebook)
        self.output_notebook.add(self.problems_tab, text="Problems")
        self.terminal_tab = ctk.CTkFrame(self.output_notebook)
        self.output_notebook.add(self.terminal_tab, text="Terminal")

        # Внутри каждой вкладки создаем текстовое поле для вывода
        self.console_box = ctk.CTkTextbox(self.console_tab, height=150)
        self.console_box.pack(fill="both", padx=5, pady=5)
        self.console_box.insert("end", ">>> Здесь будет вывод кода\n")
        self.console_box.configure(state="disabled")

        self.problems_box = ctk.CTkTextbox(self.problems_tab, height=150)
        self.problems_box.pack(fill="both", padx=5, pady=5)
        self.problems_box.insert("end", ">>> Проблемы будут отображаться здесь\n")
        self.problems_box.configure(state="disabled")

        self.terminal_box = ctk.CTkTextbox(self.terminal_tab, height=150)
        self.terminal_box.pack(fill="both", padx=5, pady=5)
        self.terminal_box.insert("end", ">>> Терминал готов\n")
        self.terminal_box.configure(state="disabled")

    def open_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.project_path = folder
            self.refresh_file_tree()

    def refresh_file_tree(self):
        for widget in self.file_tree.winfo_children():
            widget.destroy()

        for root, dirs, files in os.walk(self.project_path):
            rel_root = os.path.relpath(root, self.project_path)
            indent = rel_root.count(os.sep)
            if rel_root != ".":
                label = ctk.CTkLabel(self.file_tree, text="  " * indent + os.path.basename(root))
                label.pack(anchor="w")

            for file in files:
                path = os.path.join(root, file)
                label = ctk.CTkButton(self.file_tree, text="  " * (indent + 1) + file,
                                      fg_color="transparent", text_color="white",
                                      hover_color="#444",
                                      anchor="w",
                                      command=lambda p=path: self.open_file(p))
                label.pack(anchor="w", fill="x")

    def open_file(self, path):
        if path in self.editor_tabs:
            return

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        tab = ctk.CTkFrame(self.editor_area)
        tab.pack(fill="both", expand=True)
        textbox = ctk.CTkTextbox(tab)
        textbox.insert("1.0", content)
        textbox.pack(fill="both", expand=True)

        self.editor_tabs[path] = (tab, textbox)
        self.show_tab(path)

    def show_tab(self, path):
        for p, (tab, _) in self.editor_tabs.items():
            tab.pack_forget()
        self.editor_tabs[path][0].pack(fill="both", expand=True)
        self.current_path = path

    def save_current_file(self):
        if hasattr(self, 'current_path') and self.current_path:
            content = self.editor_tabs[self.current_path][1].get("1.0", "end")
            with open(self.current_path, "w", encoding="utf-8") as f:
                f.write(content)

    def run_current_file(self):
        if hasattr(self, 'current_path') and self.current_path.endswith(".py"):
            self.save_current_file()
            try:
                result = subprocess.run(["python", self.current_path],
                                        capture_output=True, text=True, timeout=10)
                output = result.stdout + result.stderr
            except Exception as e:
                output = f"Ошибка запуска: {e}"

            self.console_box.configure(state="normal")
            self.console_box.delete("1.0", "end")
            self.console_box.insert("1.0", output)
            self.console_box.configure(state="disabled")
    
    def open_settings(self):
        SettingsWindow(self)


if __name__ == "__main__":
    app = MyIDE()
    app.mainloop()
